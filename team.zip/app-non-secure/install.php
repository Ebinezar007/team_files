<?php
   print_r(file_get_contents($backend_url."install"));
?>