<?php

$request="$_SERVER[REQUEST_URI]";


?>
