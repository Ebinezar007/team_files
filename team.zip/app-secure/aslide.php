<div class="sidebar">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red"
    -->
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a href="javascript:void(0)" class="simple-text logo-mini">
                        <img src="https://ik.imagekit.io/bfzb9z4tav/assets/favicon_FUJbfCUAh.ico">
                    </a>
                    <a href="javascript:void(0)" class="simple-text logo-normal">
           NUTZ
          </a>
                </div>
                <ul class="nav">
                    <li class="active">
                        <a href="dashboard.html">
                            <i class="tim-icons icon-chart-pie-36"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="collapse" href="#pagesExamples">
                            <i class="tim-icons icon-image-02"></i>
                            <p>
                                Pages
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="pagesExamples">
                            <ul class="nav">
                               
                                <li>
                                    <a href="timeline.html">
                                        <span class="sidebar-mini-icon">T</span>
                                        <span class="sidebar-normal"> Timeline </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="timeline2.html">
                                        <span class="sidebar-mini-icon">T</span>
                                        <span class="sidebar-normal"> Timeline2 </span>
                                    </a>
                                </li>
                                
                                <li>
                                    <a href="user.html">
                                        <span class="sidebar-mini-icon">UP</span>
                                        <span class="sidebar-normal"> User Profile </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a url="employeManagement">
                            <i class="tim-icons icon-single-02"></i>
                            <p>
                                EMPLOYEE
                               
                            </p>
                        </a>
                    </li>
                   
                </ul>
            </div>
        </div>